from gendiff.generate import generate_diff
